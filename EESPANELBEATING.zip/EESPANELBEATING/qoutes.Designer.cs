﻿namespace EESPANELBEATING
{
    partial class qoutes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(qoutes));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.vintb = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.colortb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.vehicleregtb = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.carmdoeltb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cellnotb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.surnametb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nametb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.partstb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.painttb = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.labourtb = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.stipAsstb = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.discription = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.qntytb = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.newrepairDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paintDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labourDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stripassmFrameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quotesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.essbDATASET = new EESPANELBEATING.essbDATASET();
            this.customerDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customer_detailsTableAdapter = new EESPANELBEATING.essbDATASETTableAdapters.customer_detailsTableAdapter();
            this.quotesTableAdapter = new EESPANELBEATING.essbDATASETTableAdapters.quotesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quotesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.essbDATASET)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDetailsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(936, 513);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Location = new System.Drawing.Point(313, 503);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(187, 42);
            this.button2.TabIndex = 1;
            this.button2.Text = "Save Quote";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(7, 522);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "back";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.Location = new System.Drawing.Point(532, 503);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(187, 42);
            this.button4.TabIndex = 3;
            this.button4.Text = "print Quote";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // vintb
            // 
            this.vintb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.vintb.Location = new System.Drawing.Point(821, 37);
            this.vintb.Name = "vintb";
            this.vintb.Size = new System.Drawing.Size(100, 20);
            this.vintb.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(717, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "VIN N.o";
            // 
            // colortb
            // 
            this.colortb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.colortb.Location = new System.Drawing.Point(460, 152);
            this.colortb.Name = "colortb";
            this.colortb.Size = new System.Drawing.Size(100, 20);
            this.colortb.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(356, 159);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Color";
            // 
            // vehicleregtb
            // 
            this.vehicleregtb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.vehicleregtb.Location = new System.Drawing.Point(460, 96);
            this.vehicleregtb.Name = "vehicleregtb";
            this.vehicleregtb.Size = new System.Drawing.Size(100, 20);
            this.vehicleregtb.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(356, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Vehicle Reg N.o";
            // 
            // carmdoeltb
            // 
            this.carmdoeltb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.carmdoeltb.Location = new System.Drawing.Point(460, 37);
            this.carmdoeltb.Name = "carmdoeltb";
            this.carmdoeltb.Size = new System.Drawing.Size(100, 20);
            this.carmdoeltb.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(356, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Car Model";
            // 
            // cellnotb
            // 
            this.cellnotb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cellnotb.Location = new System.Drawing.Point(105, 152);
            this.cellnotb.Name = "cellnotb";
            this.cellnotb.Size = new System.Drawing.Size(100, 20);
            this.cellnotb.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "cell N.o";
            // 
            // surnametb
            // 
            this.surnametb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.surnametb.Location = new System.Drawing.Point(105, 92);
            this.surnametb.Name = "surnametb";
            this.surnametb.Size = new System.Drawing.Size(100, 20);
            this.surnametb.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Surname";
            // 
            // nametb
            // 
            this.nametb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nametb.Location = new System.Drawing.Point(105, 37);
            this.nametb.Name = "nametb";
            this.nametb.Size = new System.Drawing.Size(100, 20);
            this.nametb.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Name";
            // 
            // partstb
            // 
            this.partstb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.partstb.Location = new System.Drawing.Point(344, 221);
            this.partstb.Name = "partstb";
            this.partstb.Size = new System.Drawing.Size(64, 20);
            this.partstb.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(311, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "parts";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(438, 224);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "paint";
            // 
            // painttb
            // 
            this.painttb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.painttb.Location = new System.Drawing.Point(471, 221);
            this.painttb.Name = "painttb";
            this.painttb.Size = new System.Drawing.Size(64, 20);
            this.painttb.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(573, 225);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Labour";
            // 
            // labourtb
            // 
            this.labourtb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labourtb.Location = new System.Drawing.Point(615, 221);
            this.labourtb.Name = "labourtb";
            this.labourtb.Size = new System.Drawing.Size(64, 20);
            this.labourtb.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(710, 221);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "strip/assem frame";
            // 
            // stipAsstb
            // 
            this.stipAsstb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.stipAsstb.Location = new System.Drawing.Point(805, 218);
            this.stipAsstb.Name = "stipAsstb";
            this.stipAsstb.Size = new System.Drawing.Size(64, 20);
            this.stipAsstb.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 225);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "discription";
            // 
            // discription
            // 
            this.discription.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.discription.FormattingEnabled = true;
            this.discription.Items.AddRange(new object[] {
            "",
            "rear Fender left",
            "rear Fender right",
            "front Fender left",
            "front Fender right",
            "front Bonnet",
            "Boot Lid",
            "Radiato Grill",
            "front Bumper",
            "rear Bumper",
            "front Door left",
            "front Door right",
            "rear Door left",
            "rear Door right",
            "front Door Handle left",
            "front Door Handle right",
            "rear door handle left",
            "rear door handle right"});
            this.discription.Location = new System.Drawing.Point(73, 221);
            this.discription.Name = "discription";
            this.discription.Size = new System.Drawing.Size(121, 21);
            this.discription.TabIndex = 26;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(215, 226);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(27, 13);
            this.label14.TabIndex = 11;
            this.label14.Text = "qnty";
            // 
            // qntytb
            // 
            this.qntytb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.qntytb.Location = new System.Drawing.Point(244, 222);
            this.qntytb.Name = "qntytb";
            this.qntytb.Size = new System.Drawing.Size(35, 20);
            this.qntytb.TabIndex = 21;
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.Location = new System.Drawing.Point(901, 211);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 30);
            this.button5.TabIndex = 27;
            this.button5.Text = "Add";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.Location = new System.Drawing.Point(869, 442);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(122, 28);
            this.label15.TabIndex = 24;
            this.label15.Text = "Labour";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Image = global::EESPANELBEATING.Properties.Resources.sdf;
            this.label1.Location = new System.Drawing.Point(781, 548);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 81);
            this.label1.TabIndex = 4;
            // 
            // checkBox1
            // 
            this.checkBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(73, 249);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(46, 17);
            this.checkBox1.TabIndex = 29;
            this.checkBox1.Text = "new";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.newrepairDataGridViewTextBoxColumn,
            this.discriptionDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.partsDataGridViewTextBoxColumn,
            this.paintDataGridViewTextBoxColumn,
            this.labourDataGridViewTextBoxColumn,
            this.stripassmFrameDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.quotesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(36, 271);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(928, 174);
            this.dataGridView1.TabIndex = 28;
            // 
            // newrepairDataGridViewTextBoxColumn
            // 
            this.newrepairDataGridViewTextBoxColumn.DataPropertyName = "new/repair";
            this.newrepairDataGridViewTextBoxColumn.HeaderText = "new/repair";
            this.newrepairDataGridViewTextBoxColumn.Name = "newrepairDataGridViewTextBoxColumn";
            // 
            // discriptionDataGridViewTextBoxColumn
            // 
            this.discriptionDataGridViewTextBoxColumn.DataPropertyName = "discription";
            this.discriptionDataGridViewTextBoxColumn.HeaderText = "discription";
            this.discriptionDataGridViewTextBoxColumn.Name = "discriptionDataGridViewTextBoxColumn";
            this.discriptionDataGridViewTextBoxColumn.Width = 225;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            // 
            // partsDataGridViewTextBoxColumn
            // 
            this.partsDataGridViewTextBoxColumn.DataPropertyName = "parts";
            this.partsDataGridViewTextBoxColumn.HeaderText = "parts";
            this.partsDataGridViewTextBoxColumn.Name = "partsDataGridViewTextBoxColumn";
            this.partsDataGridViewTextBoxColumn.Width = 125;
            // 
            // paintDataGridViewTextBoxColumn
            // 
            this.paintDataGridViewTextBoxColumn.DataPropertyName = "paint";
            this.paintDataGridViewTextBoxColumn.HeaderText = "paint";
            this.paintDataGridViewTextBoxColumn.Name = "paintDataGridViewTextBoxColumn";
            this.paintDataGridViewTextBoxColumn.Width = 125;
            // 
            // labourDataGridViewTextBoxColumn
            // 
            this.labourDataGridViewTextBoxColumn.DataPropertyName = "labour";
            this.labourDataGridViewTextBoxColumn.HeaderText = "labour";
            this.labourDataGridViewTextBoxColumn.Name = "labourDataGridViewTextBoxColumn";
            this.labourDataGridViewTextBoxColumn.Width = 125;
            // 
            // stripassmFrameDataGridViewTextBoxColumn
            // 
            this.stripassmFrameDataGridViewTextBoxColumn.DataPropertyName = "strip/assm frame";
            this.stripassmFrameDataGridViewTextBoxColumn.HeaderText = "strip/assm frame";
            this.stripassmFrameDataGridViewTextBoxColumn.Name = "stripassmFrameDataGridViewTextBoxColumn";
            this.stripassmFrameDataGridViewTextBoxColumn.Width = 125;
            // 
            // quotesBindingSource
            // 
            this.quotesBindingSource.DataMember = "quotes";
            this.quotesBindingSource.DataSource = this.essbDATASET;
            // 
            // essbDATASET
            // 
            this.essbDATASET.DataSetName = "essbDATASET";
            this.essbDATASET.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerDetailsBindingSource
            // 
            this.customerDetailsBindingSource.DataMember = "customer details";
            this.customerDetailsBindingSource.DataSource = this.essbDATASET;
            // 
            // customer_detailsTableAdapter
            // 
            this.customer_detailsTableAdapter.ClearBeforeFill = true;
            // 
            // quotesTableAdapter
            // 
            this.quotesTableAdapter.ClearBeforeFill = true;
            // 
            // qoutes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1038, 638);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.discription);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.stipAsstb);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.labourtb);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.painttb);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.partstb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.vintb);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.colortb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.vehicleregtb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.carmdoeltb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.qntytb);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cellnotb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.surnametb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.nametb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "qoutes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = resources.GetString("$this.Text");
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.panelForm_FormClosed);
            this.Load += new System.EventHandler(this.qoutes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quotesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.essbDATASET)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDetailsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox vintb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox colortb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox vehicleregtb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox carmdoeltb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox cellnotb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox surnametb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nametb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox partstb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox painttb;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox labourtb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox stipAsstb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox discription;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox qntytb;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox checkBox1;
        private essbDATASET essbDATASET;
        private System.Windows.Forms.BindingSource customerDetailsBindingSource;
        private essbDATASETTableAdapters.customer_detailsTableAdapter customer_detailsTableAdapter;
        private System.Windows.Forms.BindingSource quotesBindingSource;
        private essbDATASETTableAdapters.quotesTableAdapter quotesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn newrepairDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn discriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paintDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn labourDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stripassmFrameDataGridViewTextBoxColumn;
    }
}