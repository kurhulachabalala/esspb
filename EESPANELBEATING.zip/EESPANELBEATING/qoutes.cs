﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using EESPANELBEATING.essbDATASETTableAdapters;

namespace EESPANELBEATING
{
    public partial class qoutes : Form
    {


        int addbtnclicked = 0;
        long custid;
        customer_detailsTableAdapter cud = new customer_detailsTableAdapter();
        quotesTableAdapter quo = new quotesTableAdapter();



        public qoutes()
        {
            InitializeComponent();
            

        }

        private void panelForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }
        public void laoddata()
        {
            dataGridView1.DataSource = quo.datagridLoader(custid);
        }
        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new panelForm().Show();
            this.Hide();
        }

       
        private void button2_Click(object sender, EventArgs e)
        {
          // printForm1.PrinterSettings =new PageSetupDialog().ShowDialog();
           
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (addbtnclicked==0)
            {
                cud.InsertNewCust(nametb.Text, surnametb.Text, cellnotb.Text);

                Thread.Sleep(500);
                //cud.GetData().Rows[0].ItemArray[0]
                string newRep="";
                if (checkBox1.Checked )
	                {
                    newRep ="new";
		 
	                }else
	                    {
                          newRep = "repair";
	                    }
                custid = Convert.ToInt64(cud.GetDataBycust( nametb.Text,surnametb.Text, cellnotb.Text).Rows[0].ItemArray[0]);
                
                quo.InsertnewQuote(custid, DateTime.Now, carmdoeltb.Text, vehicleregtb.Text, colortb.Text, vintb.Text, discription.SelectedItem.ToString(),Convert.ToInt16(qntytb.Text), newRep, Convert.ToInt16(partstb.Text), Convert.ToInt16(painttb.Text), Convert.ToInt16(labourtb.Text), Convert.ToInt16(stipAsstb.Text));
                addbtnclicked = 1;

                discription.SelectedIndex = 0;
                qntytb.Text = "";
                painttb.Text = "";
                labourtb.Text = "";
                partstb.Text = "";
                stipAsstb.Text = "";
                checkBox1.Checked = false;
                laoddata();
            }
            else
            {
                string newRep = "";
                if (checkBox1.Checked)
                {
                    newRep = "new";

                }
                else
                {
                    newRep = "repair";
                }
                long custid = Convert.ToInt64(cud.GetDataBycust( nametb.Text,surnametb.Text, cellnotb.Text).Rows[0].ItemArray[0]);
                quo.InsertnewQuote(custid, DateTime.Now, carmdoeltb.Text, vehicleregtb.Text, colortb.Text, vintb.Text, discription.SelectedItem.ToString(), Convert.ToInt16(qntytb.Text), newRep, Convert.ToInt16(partstb.Text), Convert.ToInt16(painttb.Text), Convert.ToInt16(labourtb.Text), Convert.ToInt16(stipAsstb.Text));

                discription.SelectedIndex = 0;
                qntytb.Text = "";
                painttb.Text = "";
                labourtb.Text = "";
                partstb.Text = "";
                stipAsstb.Text = "";
                checkBox1.Checked = false;
                laoddata();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new MakeInvoice(1).Show();
            this.Dispose();
        }

        private void qoutes_Load(object sender, EventArgs e)
        {
            
            // TODO: This line of code loads data into the 'essbDATASET.customer_details' table. You can move, or remove it, as needed.
            this.customer_detailsTableAdapter.Fill(this.essbDATASET.customer_details);

        }

       
    }
}
