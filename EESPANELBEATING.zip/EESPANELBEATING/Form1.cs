﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace EESPANELBEATING
{
    public partial class Form1 : Form
    {
        int fwidth = 349;
        int fhieght = 315;
        
        public Form1()
        {
            InitializeComponent();
        }
        

        private void timer1_Tick(object sender, EventArgs e)
        {
            while (timer1.Enabled==true)
            {
                fwidth++;
                fhieght++;

               
               
                if (fwidth==1028)
                {
                   // WindowState = FormWindowState.Maximized;
                    timer1.Enabled = false;
                    //this.BackColor = Color.FloralWhite;
                    Thread.Sleep(500);
                    
                    
                    new panelForm().Show();
                    this.Hide();
                }
            }
        }
    }
}
