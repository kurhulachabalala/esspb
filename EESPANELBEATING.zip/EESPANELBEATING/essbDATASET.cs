﻿namespace EESPANELBEATING {
    
    
    public partial class essbDATASET {
    }
}

namespace EESPANELBEATING.essbDATASETTableAdapters {
    
    
    public partial class quotesTableAdapter {
    }
}
