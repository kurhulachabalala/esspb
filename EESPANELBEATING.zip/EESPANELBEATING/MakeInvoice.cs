﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EESPANELBEATING
{
    public partial class MakeInvoice : Form
    {
        int choice = 0;
        public MakeInvoice()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        public MakeInvoice(int choices)
        {
            InitializeComponent();
            choice = choices;
          
        }

        private void panelForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MakeInvoice_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (choice==1)
            {
                 new qoutes().Show();
            this.Hide();
            }
            else
            {
                if (choice==2)
                {
                    new invoice().Show();
                    this.Hide();
                }
            }
           
        }
    }
}
