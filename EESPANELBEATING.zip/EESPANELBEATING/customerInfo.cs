﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using EESPANELBEATING.essbDATASETTableAdapters;

namespace EESPANELBEATING
{
    public partial class customerInfo : Form
    {
        customer_detailsTableAdapter cusD = new customer_detailsTableAdapter();
        int custID;

        public customerInfo()
        {
            InitializeComponent();
            
        }

        private void panelForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new panelForm().Show();
            this.Hide();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            dataGridView1.DataSource = cusD.searchByName(textBox1.Text + '%');
                
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            dataGridView1.DataSource = cusD.searchBySurname(textBox2.Text + '%');
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            dataGridView1.DataSource = cusD.searchByCellNo(textBox3.Text + '%');


            //dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            custID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);

            dataGridView1.DataSource = cusD.getWithCar(custID);
            

            textBox1.Text=dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text=dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text=dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            
            textBox5.Text=dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox6.Text=dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            textBox7.Text=dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            textBox8.Text=dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
        }

        private void customerInfo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'essbDATASET.customer_details' table. You can move, or remove it, as needed.
            this.customer_detailsTableAdapter.Fill(this.essbDATASET.customer_details);

        }
    }
}
